package list;
import com.cycling74.max.*;
/**
 *
 * TODO describe the class
 * 
 * created on 7-Apr-2004
 * @author bbn
 */
public class Demultiplex extends ListProcessor {
	
	private int size;
	
	Demultiplex(Atom[] a) {
		if (a.length > 0)
			size = a[0].toInt();
		else
			size = 2;
		declareIO(1, size);
	}
	
	public void input(int idx, Atom[] a) {
		int base = a.length / size;
		int extra = a.length - size*(a.length/size);
		Atom[][] out = new Atom[size][];
		for (int i=0;i<size;i++) 
			if (i < extra)
				out[i] = new Atom[base+1];
			else
				out[i] = new Atom[base];
	
		for (int i=0;i<base;i++) 
			for (int j=0;j<size;j++) 
				out[j][i]=a[i*size+j];
			
		for (int j=0;j<extra;j++) 
			out[j][base]=a[base*size+j];
		
		for (int j=0;j<size;j++) 
			setOutput(j, out[j]);
	}

}
