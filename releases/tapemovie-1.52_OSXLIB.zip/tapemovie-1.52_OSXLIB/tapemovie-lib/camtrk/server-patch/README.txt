CAMTRK_server works with Max 4.5.7 and needs SoftVNS 2. It can also be used as a standalone application.


